package com.mwood.smartinventorymobile;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class NotificationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_notifications);

        Button btnRequestPermission = findViewById(R.id.btn_request_sms_permission);
        Button btnBackToDashboard = findViewById(R.id.btn_back_to_dashboard);
        TextView tvSmsStatusDisplay = findViewById(R.id.tv_sms_status_display);

        btnRequestPermission.setOnClickListener(v ->
                // Fixed translation warning: Using getString() to resolve resource pointers dynamically
                tvSmsStatusDisplay.setText(getString(R.string.status_alerts_enabled))
        );

        btnBackToDashboard.setOnClickListener(v -> {
            Intent intent = new Intent(NotificationActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }
}