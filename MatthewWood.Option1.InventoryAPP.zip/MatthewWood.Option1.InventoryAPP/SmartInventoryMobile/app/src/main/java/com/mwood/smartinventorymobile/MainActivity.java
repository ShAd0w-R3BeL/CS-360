package com.mwood.smartinventorymobile;

import android.content.Intent;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Fixed field warning: Converted to a clean local variable within onCreate
        Button btnNavNotifications = findViewById(R.id.btn_nav_notifications);

        // Fixed anonymous class warning: Replaced with a modern Java lambda expression
        btnNavNotifications.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, NotificationActivity.class);
            startActivity(intent);
        });
    }
}